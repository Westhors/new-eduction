<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Enums\DeviceType;
use App\Enums\StorageType;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('devices', function (Blueprint $table) {
            $table->id();
            $table->string('type')->default(DeviceType::LAPTOP->value); // Device type using Enum
            $table->string('serial_number')->unique(); // Unique serial number
            $table->string('brand'); // Manufacturer (e.g., Dell, HP, Canon)
            $table->string('model'); // Specific model (e.g., XPS 13, HP Elitebook)

            // CPU specs (for devices that need them)
            $table->string('cpu')->nullable();

            // RAM specs (for devices that need them)
            $table->integer('ram_size')->nullable(); // in GB
            $table->string('ram_type')->nullable(); // DDR4, DDR5, etc.

            // Storage specs (for devices that need them)
            $table->integer('storage_size')->nullable(); // in GB
            $table->string('storage_type')->nullable(); // Storage type using Enum

            // Graphics specs (optional, for laptops/PCs)
            $table->string('gpu_model')->nullable(); // GPU Model
            $table->integer('gpu_vram')->nullable(); // VRAM in MB

            $table->foreignIdFor(\App\Models\User::class)->nullable()->constrained()->nullOnDelete(); // Current user


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('devices');
    }
};
