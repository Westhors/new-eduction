<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description')->nullable();
            $table->timestamp('open_at')->nullable(); // Timestamp when the ticket is opened
            $table->timestamp('close_at')->nullable(); // Timestamp when the ticket is closed
            $table->foreignIdFor(\App\Models\User::class, 'employee_id') // Employee who created the ticket
                ->constrained('users') // Ensure it references the 'users' table
                ->nullOnDelete(); // Set to NULL if the user is deleted
            $table->foreignIdFor(\App\Models\User::class, 'help_desk_id') // Help desk personnel assigned to the ticket
                ->nullable() // Make this field optional
                ->constrained('users') // Ensure it references the 'users' table
                ->nullOnDelete(); // Set to NULL if the user is deleted
            $table->timestamps(); // Default Laravel timestamps for created_at and updated_at
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tickets');
    }
};
